CREATE TABLE clients (
    userid varchar(255),
    uniqueid INT
);