CREATE TABLE giveawayentrys (
    gid varchar(255),
    userid varchar(255)
);