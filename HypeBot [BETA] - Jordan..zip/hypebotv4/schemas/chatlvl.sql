CREATE TABLE chatlvl (
    userid text,
    userxp INT,
    userlvl INT
);