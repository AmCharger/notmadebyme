CREATE TABLE shop (
    productId INT,
    productName TEXT,
    productPrice INT
);