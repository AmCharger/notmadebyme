CREATE TABLE stickymsgs (
    channel varchar(255),
    message TEXT,
    embed varchar(255),
    color TEXT
);