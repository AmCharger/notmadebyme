CREATE TABLE owneditems (
    productId INT,
    productName TEXT,
    userid varchar(255)
);