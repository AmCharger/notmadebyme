CREATE TABLE birthdays (
    userid TEXT,
    deDate TEXT
);