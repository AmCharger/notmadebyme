CREATE TABLE giveaways (
    prize TEXT,
    winners TEXT,
    timelimit TEXT,
    uniqueid INT,
    messageid varchar(255),
    channelid varchar(255),
    active varchar(255),
    starter varchar(255)
);