CREATE TABLE marriage (
    userid varchar(255),
    spouse varchar(255)
);