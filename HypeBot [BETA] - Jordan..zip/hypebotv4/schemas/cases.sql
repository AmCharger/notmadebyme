CREATE TABLE cases (
    userid varchar(255),
    reason text,
    uniqueid varchar(255),
    enforcerid varchar(255),
    type varchar(255)
);