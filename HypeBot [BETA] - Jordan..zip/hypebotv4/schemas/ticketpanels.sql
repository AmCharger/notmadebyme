CREATE TABLE ticketpanels (
    uniqueid varchar(255),
    messageid varchar(255),
    title TEXT,
    categoryid varchar(255),
    openmessage TEXT
);