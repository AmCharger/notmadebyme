CREATE TABLE stats (
    tickets INT,
    counted INT
);

INSERT INTO stats (tickets, counted) VALUES (0, 0);