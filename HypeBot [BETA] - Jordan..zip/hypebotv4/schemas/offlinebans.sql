CREATE TABLE offlinebans (
    id varchar(255),
    reason text
);